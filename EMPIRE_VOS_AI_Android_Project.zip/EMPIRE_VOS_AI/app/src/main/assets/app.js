const $ = (id) => document.getElementById(id);
const promptBox = $('prompt'), messages = $('messages'), welcome = $('welcome');
let currentMode = 'chat';
const modeNames = {chat:'Trợ lý AI',learn:'Học tập',code:'Lập trình',analyze:'Phân tích',create:'Sáng tạo'};
const modePrompts = {
 chat:'Bạn đang ở chế độ trợ lý AI đa năng.',
 learn:'Chế độ Học tập giúp chia nhỏ chủ đề và giải thích theo từng bước.',
 code:'Chế độ Lập trình giúp phác thảo giải pháp, viết ví dụ và gợi ý kiểm tra lỗi.',
 analyze:'Chế độ Phân tích giúp sắp xếp dữ kiện, giả định, rủi ro và lựa chọn.',
 create:'Chế độ Sáng tạo hỗ trợ phát triển ý tưởng, nội dung và bản nháp.'
};
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2400)}
function addMessage(text,who){
  welcome.style.display='none';
  const row=document.createElement('div');row.className='message '+who;
  if(who==='ai'){const mark=document.createElement('div');mark.className='mini-mark';mark.textContent='E';row.appendChild(mark)}
  const bubble=document.createElement('div');bubble.className='bubble';bubble.textContent=text;row.appendChild(bubble);
  messages.appendChild(row);messages.scrollTop=messages.scrollHeight;return bubble;
}
function demoReply(input){
  const q=input.toLowerCase();
  let intro = 'Mình đã nhận được yêu cầu của bạn. ';
  if(currentMode==='learn'||/giải thích|học|là gì|dạy/.test(q))
    return 'BẢN DEMO — CHẾ ĐỘ HỌC TẬP\\n\\nĐể học hiệu quả, hãy chia chủ đề thành các phần nhỏ:\\n1. Nắm khái niệm cốt lõi.\\n2. Xem một ví dụ đơn giản.\\n3. Tự thực hành một bài nhỏ.\\n4. Kiểm tra lại bằng cách giải thích theo lời của bạn.\\n\\nĐây là phản hồi mẫu của giao diện, chưa phải câu trả lời do mô hình AI tạo ra. Khi kết nối backend AI, hệ thống có thể tạo câu trả lời riêng theo câu hỏi của bạn.';
  if(currentMode==='code'||/code|lập trình|html|javascript|android|apk/.test(q))
    return 'BẢN DEMO — CHẾ ĐỘ LẬP TRÌNH\\n\\nQuy trình gợi ý:\\n1. Xác định chức năng cần làm.\\n2. Chọn nền tảng và công nghệ.\\n3. Tạo phiên bản nhỏ chạy được.\\n4. Kiểm tra lỗi và cải tiến từng phần.\\n\\nKhi có mô hình AI kết nối, bạn có thể yêu cầu tạo mã nguồn và giải thích từng dòng. Đừng chạy mã không rõ nguồn gốc trên thiết bị chính.';
  if(currentMode==='analyze')
    return 'BẢN DEMO — CHẾ ĐỘ PHÂN TÍCH\\n\\nKhung phân tích:\\n• Mục tiêu: kết quả bạn muốn đạt.\\n• Dữ kiện: những gì đã biết.\\n• Giả định: điều chưa được xác minh.\\n• Lựa chọn: các hướng có thể thực hiện.\\n• Rủi ro: điều có thể không như kỳ vọng.\\n• Bước tiếp theo: một hành động nhỏ có thể kiểm tra.\\n\\nĐây là mẫu minh họa, không phải phân tích AI thực.';
  if(currentMode==='create')
    return 'BẢN DEMO — CHẾ ĐỘ SÁNG TẠO\\n\\nThử phát triển ý tưởng theo 3 lớp:\\n1. Ý tưởng cốt lõi — điều khiến nó đáng nhớ.\\n2. Điểm khác biệt — vì sao người khác quan tâm.\\n3. Bản thử nghiệm — cách thể hiện nhanh nhất.\\n\\nKhi kết nối AI thật, hệ thống có thể viết bản nháp cụ thể dựa trên ý tưởng bạn nhập.';
  return intro+'Hiện EMPIRE VOS AI đang chạy ở chế độ giao diện demo, vì vậy mình chưa thể tạo câu trả lời thông minh theo nội dung riêng của bạn.\\n\\nĐể bật AI thật, cần kết nối một backend an toàn với mô hình AI. Hãy mở ⚙ Cài đặt để xem trường nhập địa chỉ backend. Lưu ý: nhập địa chỉ ở đó chưa tự kết nối nếu máy chủ chưa được triển khai.';
}
function send(text){
  const value=(text===undefined?promptBox.value:text).trim();if(!value)return;
  addMessage(value,'user');promptBox.value='';promptBox.style.height='auto';
  const reply=addMessage('Đang chuẩn bị phản hồi demo…','ai');
  $('sendBtn').disabled=true;
  setTimeout(()=>{reply.textContent=demoReply(value);$('sendBtn').disabled=false;messages.scrollTop=messages.scrollHeight},450);
}
$('sendBtn').addEventListener('click',()=>send());
promptBox.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}});
promptBox.addEventListener('input',()=>{promptBox.style.height='auto';promptBox.style.height=Math.min(promptBox.scrollHeight,150)+'px'});
document.querySelectorAll('.suggestion').forEach(b=>b.addEventListener('click',()=>{promptBox.value=b.dataset.prompt;promptBox.focus();promptBox.style.height='auto';promptBox.style.height=Math.min(promptBox.scrollHeight,150)+'px'}));
document.querySelectorAll('.nav').forEach(b=>b.addEventListener('click',()=>{
  currentMode=b.dataset.mode;$('modeName').textContent=modeNames[currentMode];
  document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n===b));
  $('sidebar').classList.remove('open');toast(modeNames[currentMode]+' đã chọn');
  if(messages.children.length===0){welcome.style.display='';}
}));
$('newChat').addEventListener('click',()=>{messages.innerHTML='';welcome.style.display='';promptBox.value='';$('sidebar').classList.remove('open');});
$('menuBtn').addEventListener('click',()=>$('sidebar').classList.toggle('open'));
$('settingsBtn').addEventListener('click',()=>{$('settingsModal').classList.add('open');$('apiUrl').value=localStorage.getItem('empire_backend_url')||''});
$('closeSettings').addEventListener('click',()=>$('settingsModal').classList.remove('open'));
$('settingsModal').addEventListener('click',e=>{if(e.target===$('settingsModal'))$('settingsModal').classList.remove('open')});
$('saveSettings').addEventListener('click',()=>{const url=$('apiUrl').value.trim();if(url&&!/^https:\/\//i.test(url)){toast('Hãy dùng địa chỉ HTTPS an toàn');return}localStorage.setItem('empire_backend_url',url);$('savedNote').textContent=url?'Đã lưu địa chỉ trên thiết bị. Chưa gửi yêu cầu tới máy chủ.':'Đã xóa địa chỉ backend.';});
