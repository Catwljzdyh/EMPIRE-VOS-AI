# EMPIRE VOS AI — Android starter project

## Trạng thái
- Đã có: giao diện mobile trắng/bạc, menu chế độ, màn hình chat, thẻ gợi ý, nhập/gửi tin nhắn, phản hồi demo theo chế độ, hộp cài đặt lưu URL backend trong bộ nhớ cục bộ.
- Chưa có: mô hình AI thực, API chat, nhận dạng/đọc giọng nói, tài khoản, đồng bộ đám mây, phân tích tệp, backend. Các câu trả lời hiện tại là mẫu minh họa.
- Không đặt API key bí mật trong APK. Hãy để khóa ở backend do bạn kiểm soát.

## Mở dự án
1. Cài Android Studio trên máy tính.
2. Giải nén ZIP.
3. Android Studio > Open > chọn thư mục `EMPIRE_VOS_AI`.
4. Chờ Gradle Sync. Nếu được hỏi cài Android SDK Platform 35 hoặc Build Tools, chọn Install.
5. Chạy trên máy ảo Android hoặc bật Developer options + USB debugging trên điện thoại rồi nhấn Run.

## Build APK
1. Android Studio > Build > Build Bundle(s) / APK(s) > Build APK(s).
2. Khi hoàn tất, chọn Locate. APK debug thường ở `app/build/outputs/apk/debug/app-debug.apk`.
3. Chuyển APK sang điện thoại và cài đặt. Có thể cần cho phép cài ứng dụng từ nguồn đó trong Android.
4. Để phát hành chính thức, dùng Build > Generate Signed Bundle / APK và tạo keystore riêng, giữ an toàn.

## Muốn kết nối AI thật
Cần triển khai một backend HTTPS có endpoint chat, xác thực người dùng, giới hạn tần suất và gọi API của nhà cung cấp mô hình. Sau đó cập nhật `app.js` để gửi tin nhắn tới endpoint theo hợp đồng API của backend. Trường URL trong Cài đặt hiện chỉ lưu địa chỉ; nó chưa tự gửi tin nhắn.
